<?php
	define('EMAIL', 'fromaddress@gmail.com');
	define('PASS', 'from_email_password');
?>