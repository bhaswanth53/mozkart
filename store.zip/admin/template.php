<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="refresh" content="0;url=pages/index.html">
    <title>Startmin</title>
    <script language="javascript">
        window.location.href = "pages/index.html"
    </script>
</head>
<body>
<a href="pages/index.html">Go to Demo</a>
</body>
</html>
