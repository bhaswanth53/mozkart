<?php
    $con = mysqli_connect("localhost","root","","store") or die(mysqli_error);
	//$con = mysqli_connect("localhost","nexevote_Shahul","Hameed@786","nexevote_store") or die(mysqli_error);
	//$con = mysqli_connect("localhost","u297659122_store","basu533274","u297659122_store") or die(mysqli_error);
?>